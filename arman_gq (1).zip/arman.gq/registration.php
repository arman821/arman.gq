<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: index.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
  
      
      
  /*
Template Name: simple-plain-login
File Name: style.css
Author Name: ThemeVault
Author URI: http://www.themevault.net/
Licence URI: http://www.themevault.net/license/
*/

html {
    margin: 0;
    padding: 0;
}
body {
    font-family: 'PT Sans', sans-serif !important;
    margin: 0;
    padding: 40px 0;
    font-size:100%;
    letter-spacing: 1px; 
  background-color: #1e3953;
}
textarea:focus, input:focus, select:focus, select:active{
    outline: none;
    box-shadow:none;
}
.form-control:focus {
    box-shadow: none;
    outline: 0 none;
}
a{
    text-decoration: none;
}
.btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {outline: none;}
a,h1,h3,h4,h5{cursor: pointer;}
a:focus, a:hover{text-decoration: none;}
a:focus {outline: none; outline-offset: 0;}
ul{list-style: none;}
.placeholder-fix:focus::-webkit-input-placeholder  {color:transparent !important; }
.placeholder-fix:focus::-moz-placeholder   {color:transparent !important;}
.placeholder-fix:-moz-placeholder   {color:transparent !important;}
.logo h2 {
    font-size: 24px;
    letter-spacing: 3px;
    text-transform: uppercase;
    font-weight: 900;
    padding-bottom:40px;
    color:fff;
}
.content{
    background-color:#1e3953;
    text-align: center;
}
.login-page {
    background-color: #fff;
    box-shadow: 0 0 20px 10px rgba(38, 50, 56, 0.08);
    margin: 0 auto;
    width:460px;   
}
.login-page h3 {
    background-color: #88bb39;
    color: #fff;
    font-size: 22px;
    font-weight: 600;
    letter-spacing: 1px;
    margin: 0;
    padding: 30px;
    text-align: left;
    text-transform: capitalize;
}
.login-page .form-control {
    background-color: #f0eef0 !important;
    background-image: none;
    border: 1px solid #88bb39;
    border-radius: 5px;
    color: #1e3953;
    display: block;
    font-size: 14px;
    height: 35px;
    letter-spacing: 1px;
    margin: 0 auto 15px;
    padding: 6px 10px;
    width: 300px;
    font-weight: 600;
}
.action-button button{
    width:300px;
    margin: 0 auto;
}
button {
    background: rgb(136, 187, 57) none repeat scroll 0 0;
    border: medium none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    margin-right: 10px;
    padding: 8px 20px;
}
.input-value input:first-child{
    background: url(../images/user.png);
    background-repeat: no-repeat;
    background-position: right center;
    background-origin: content-box;
}

.input-value input:last-child{
    background: url(../images/psw.png);
    background-repeat: no-repeat;
    background-position: right center;
    background-origin: content-box;
}
form {
    padding: 50px 0 20px;
}
.form-control::-moz-placeholder {
    color: #1e3953;
    font-weight: 600;
    opacity: 1;
}
.form-control::-webkit-input-placeholder{
    color: #1e3953;
    font-weight: 600;
    opacity: 1;
}
.input-value {
    padding: 0px 0 10px;
}
.page-links {
    padding: 0;
    text-align: center;
    padding: 20px 0;
}
.page-links li{
    display: inline-block;
}
.page-links a {
    color: rgb(30,57,83);
    font-size: 16px;
    font-weight: 600;
} 
.social-icon{
    margin: 50px 0;
}
.social-icon a{
    margin-right: 5px;      
}
.copyright {
    color: #fff;
    font-size: 16px;
}
.copyright a, .copyright a:hover{
    color:#88bb39;
    text-decoration: none;
}

/*media query*/
@media (max-width: 700px){
    .login-page .form-control {
        font-size: 13px;
        height: 30px;
        width: 250px;
    }
    .login-page {
        width: 400px;
    }
    .login-page h3 {
        font-size: 25px;
        padding: 20px;
    }
    .action-button button {
        margin: 0 auto;
        width: 250px;
    }
    form {
        padding: 30px 0 1px;
    }
    .logo h2 {
        padding-bottom: 20px;
        color:White;
    }
    .social-icon {
        margin: 40px 0;
    }
    button{
        font-size: 15px;
    }
    .page-links a {
        font-size: 14px;
    }
    .page-links {
        padding: 10px 0;
    }
}
@media (max-width: 370px){
    .login-page {
        width: 280px;
    }
    .login-page .form-control {
        font-size: 12px;
        height: 25px;
        width: 200px;
        margin: 0 auto 10px;
    }
    .action-button button {
        margin: 0 auto;
        width: 200px;
    }
    .page-links a {
        font-size: 13px;
    }
    button {
        font-size: 14px;
        padding: 8px;
    }
    .page-links {
    padding: 0;
}
h2{
    color:white;
}
    </style>
</head>
<body>
    <center>
        <img src="https://arman.gq/wp-content/uploads/2020/02/iconfinder_icon-1-cloud_316014-42x42.png"/>
        <div class="login-page text-center">
    <div class="wrapper">
        <h3>Sign Up</h3>
       
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="index.php">Login here</a>.</p>
        </form>
        
       
    </center>
    </div>
    </div>
</body>
</html>
