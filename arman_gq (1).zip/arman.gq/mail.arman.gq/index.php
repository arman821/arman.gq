<?php
echo '<script>alert("Fuck")</script>';

?>